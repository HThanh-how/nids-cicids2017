SOICT 2026, paper 9222: How Optimistic Is Your Intrusion-Detection Benchmark? Leakage-Resistant Evaluation and Measured Serving Cost

poster/        A0 portrait (841 x 1189 mm) poster: PDF (final), PPTX (single full-slide picture), poster.html + make_poster.py + fonts (generator; "py make_poster.py --all" rebuilds HTML, PDF and PPTX; needs Chrome, pdftocairo, python-pptx, segno)
oral_slides/   15-slide oral deck (12 main + 3 backup): PDF and the interactive HTML (PPTX with speaker notes available on request)
Code and data: https://github.com/HThanh-how/nids-cicids2017
